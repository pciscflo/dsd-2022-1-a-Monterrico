package com.upc.appproducto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppProductoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppProductoApplication.class, args);
    }

}
