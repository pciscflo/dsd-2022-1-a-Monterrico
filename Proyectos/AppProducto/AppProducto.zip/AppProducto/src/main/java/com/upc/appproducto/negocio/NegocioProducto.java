package com.upc.appproducto.negocio;

import com.upc.appproducto.entidades.Producto;
import com.upc.appproducto.repositorio.IRepositorioProducto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NegocioProducto {
    @Autowired //inyectamos al repositorio
    private IRepositorioProducto iRepositorioProducto;

    public Producto registrar(Producto producto){
        return iRepositorioProducto.save(producto);
    }
    public List<Producto> obtenerListado(){
        return iRepositorioProducto.findAll();
    }
}
