package com.upc.appproducto;

import com.upc.appproducto.entidades.Producto;
import com.upc.appproducto.negocio.NegocioProducto;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
class AppProductoApplicationTests {
    //inyectando al negocio para probarlo
    @Autowired
    private NegocioProducto negocioProducto;

    @Test
    void contextLoads() {
    }
    @Test
    public void probarRegistro(){
        Producto producto = new Producto();
        producto.setPrecio(2);
        producto.setDescripcion("Sublime");
        producto.setStock(50);
        Producto p;
        p = negocioProducto.registrar(producto);
        Assert.assertNotNull(p);

    }
    @Test
    public void probarListado(){
        List<Producto> listado;
        listado = negocioProducto.obtenerListado();
        for(Producto p: listado){
            System.out.println(p.toString());
        }
        Assert.assertNotNull(listado);
    }

}
